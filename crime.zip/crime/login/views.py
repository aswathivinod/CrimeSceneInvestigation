from django.shortcuts import render
from login.models import Login
# Create your views here.
def log(request):
    if request.method == "POST":
        uname = request.POST.get('unam')
        passw = request.POST.get('pswd')
        obj = Login.objects.filter(username=uname, password=passw)

        tp = ""
        for ob in obj:
            tp = ob.type
            uid = ob.uid
            mail = ob.username
            if tp == "admin":
                request.session["uid"] = uid
                request.session["mail"] = mail

                return render(request, 'login/adminhome.html')
            elif tp == "user":
                request.session['uid'] = uid
                return render(request, 'login/userhome.html')
            elif tp == "women":
                request.session['uid'] = uid
                return render(request, 'login/womenhome.html')
            elif tp == "civil":
                request.session['uid'] = uid
                return render(request, 'login/civilhome.html')


            else:
                context = {
                    'msg': "invalid credentioal"
                }
                return render(request, 'login/login.html', context)

    return render(request, 'login/login.html')

def logout(request):
        request.session["uid"] = ''
        request.session["mail"] = ''

        return log(request)


def adminhome(request):
    return render(request,'login/adminhome.html')
def userhome(request):
    return render(request,'login/userhome.html')
def civilhome(request):
    return render(request,'login/civilhome.html')
def womenhome(request):
    return render(request,'login/womenhome.html')
def about(request):
    return render(request,'login/About.html')
def contact(request):
    return render(request,'login/Contact.html')