from django.conf.urls import url, include
from login import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.log, name='log'),
    url('^adminhome/',views.adminhome,name='adminhome'),
    url('^userhome/',views.userhome,name='userhome'),
    url('^civilhome/',views.civilhome,name='civilhome'),
    url('^womenhome/',views.womenhome,name='womenhome'),
    url('^about/',views.about,name='about'),
    url('^contact/',views.contact,name='contact'),

]

