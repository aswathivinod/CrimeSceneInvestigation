from django.shortcuts import render

# Create your views here.
def res(request):
    return render(request,'result/addreport.html')