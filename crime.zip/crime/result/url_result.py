from django.conf.urls import url, include
from result import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.res, name='res')
]

