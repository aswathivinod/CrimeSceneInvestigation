from django.shortcuts import render
from notification.models import Notification
from django.http import HttpResponse
# Create your views here.
def add(request):
    if request.method == "POST":
        obj = Notification()
        obj.subject = request.POST.get("SUB")

        obj.publisheddate = request.POST.get("pdat")

        obj.save()
    return render(request, 'notification/addnotification.html')
   # return HttpResponse('sucess')
def xy(request):
            objlist =  Notification.objects.all()
            context = {
                'objval': objlist,
            }
            return render(request, 'notification/Viewnotification.html', context)
