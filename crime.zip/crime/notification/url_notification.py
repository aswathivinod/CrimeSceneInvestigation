from django.conf.urls import url, include
from notification import views
from django.conf.urls import url, include

urlpatterns = [

    url('^$', views.add, name='add'),
    url('^xyz/', views.xy, name='xy'),
]

