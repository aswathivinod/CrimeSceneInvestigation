from django.apps import AppConfig


class UserregConfig(AppConfig):
    name = 'userreg'
