from django.shortcuts import render
from userreg.models import Userreg
from django.db.models import Max
from login.models import Login
# Create your views here.
def ureg(request):
    if request.method == "POST":
        obj = Userreg()

        ob = Login()
        sid = Userreg.objects.all().aggregate(Max('uid'))

        sidd = list(sid.values())[0]

        siddv = ''
        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0
        obj.uid = sidd + 1

        ob.uid = sidd + 1
        ob.username =request.POST.get("email")
        ob.password = request.POST.get("pass")
        ob.type="user"

        ob.save()

        obj.name = request.POST.get("cname")
        obj.address = request.POST.get("address")
        obj.email = request.POST.get("email")
        obj.gender = request.POST.get("Gender")
        obj.dob = request.POST.get("Date")
        obj.phoneno = request.POST.get("mobile")
        obj.district = request.POST.get("dist")

        obj.save()
        context={
            'msg': "SUCESSFULLY REGISTERED"
        }
        return render(request, 'userreg/Userregistration.html', context)
    return render(request,'userreg/Userregistration.html')



def gg(request):
    objlist = Userreg.objects.all()
    context = {
        'objval': objlist,
    }

    return render(request,'userreg/viewuserreg.html',context)