from django.conf.urls import url, include
from userreg import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.ureg, name='ureg'),
    url('^gg/', views.gg, name='gg'),
]

