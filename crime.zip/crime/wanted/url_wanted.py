from django.conf.urls import url, include
from wanted import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.wntd, name='wntd'),
    url('^ab/', views.ab, name='ab'),
]

