from django.shortcuts import render
from wanted.models import Wanted

# Create your views here.
def wntd(request):
    if request.method == "POST":
        obj = Wanted()
        obj.name = request.POST.get("name")
        obj.age = request.POST.get("age")
        obj.crimedetails = request.POST.get("cdetail")
        obj.missingdate = request.POST.get("dat")
        obj.missinglocation = request.POST.get("mloc")
        obj.marks = request.POST.get("mark")
        obj.district = request.POST.get("dist")
        obj.contact = request.POST.get("mobile")
        obj.image = request.POST.get("filename")
        obj.save()

    return render(request,'wanted/wanted.html')
def ab(request):
    objlist = Wanted.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'wanted/Viewwantedlist.html',context)