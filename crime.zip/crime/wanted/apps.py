from django.apps import AppConfig


class WantedConfig(AppConfig):
    name = 'wanted'
