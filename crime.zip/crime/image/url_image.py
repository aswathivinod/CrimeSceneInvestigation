from django.conf.urls import url, include
from image import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.img, name='img')
]

