from django.conf.urls import url, include
from casereg import views
from django.conf.urls import url, include

urlpatterns = [
    url('^$', views.case, name='case'),
    url('^upimg/', views.upimg, name='upimg'),

]

