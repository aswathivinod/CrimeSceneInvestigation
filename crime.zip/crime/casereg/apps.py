from django.apps import AppConfig


class CaseregConfig(AppConfig):
    name = 'casereg'
