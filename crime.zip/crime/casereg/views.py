from django.shortcuts import render
from casereg.models import Casereg
from image.models import Image
from django.db.models import Max
from login.models import Login
from django.http import HttpResponse,HttpResponseRedirect
# Create your views here.
def case(request):
    if request.method == "POST":
        obj = Casereg()
        sid = Casereg.objects.all().aggregate(Max('caseno'))

        sidd = list(sid.values())[0]

        request.session["caseno"]=sidd + 1

        obj.subject = request.POST.get("sbjct")
        obj.details = request.POST.get("detail")
        obj.date = request.POST.get("incdat")
        obj.time = request.POST.get("inctim")
        obj.place = request.POST.get("incplc")
        obj.uid =  request.session['uid']
        obj.caseno = sidd + 1
        obj.status = 'pending'
        obj.current_status ='pending'
        obj.save()
        # obj.image=" "





        check= request.POST.get("grp")
        if check=='yes':
            #return  upimg(request)
            #return render(request, 'casereg/upload.html')
            return HttpResponseRedirect('/casereg/upimg/')



    return render(request,'casereg/Caseregistration.html')

def upimg(request):
   if request.method == "POST":
       obj = Image()
       obj.cid = request.session['caseno']
       obj.imagepath = request.POST.get("filename")
       obj.save()
       context = {
           'msg': "SUCESSFULLY REGISTERED"
       }
       return render(request, 'casereg/upload.html', context)
   return render(request, 'casereg/upload.html')
