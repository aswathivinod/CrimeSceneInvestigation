from django.apps import AppConfig


class FindingsConfig(AppConfig):
    name = 'findings'
