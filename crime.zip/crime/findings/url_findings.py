from django.conf.urls import url, include
from findings import views


urlpatterns = [
    url('^$', views.findg, name='findg')
]

