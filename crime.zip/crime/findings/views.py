from django.shortcuts import render

# Create your views here.
def findg(request):
    return render(request,'findings/addfindings.html')