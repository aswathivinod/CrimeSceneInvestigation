from django.apps import AppConfig


class AllocationConfig(AppConfig):
    name = 'allocation'
