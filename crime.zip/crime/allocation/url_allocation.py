from django.conf.urls import url,include
from allocation import views
from django.conf.urls import  url,include

urlpatterns = [
    url('^$',views.allo,name='allo')
    ]

